def Sum(var1, var2):
    for i in range(1,10+1):
        return f"Sum of {var1} and {var2} is {var1+var2}"